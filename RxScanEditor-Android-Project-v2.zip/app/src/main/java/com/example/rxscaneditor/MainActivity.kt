package com.example.rxscaneditor

import android.app.Activity
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : ComponentActivity() {
    private lateinit var preview: ImageView
    private lateinit var editor: EditText

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            preview.setImageURI(uri)
            recognizeText(uri)
        }
    }
    private val createPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) writePdf(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(Color.rgb(248, 250, 252))
        }
        root.addView(TextView(this).apply {
            text = "Rx Scan Editor"; textSize = 24f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(25, 55, 90)); setPadding(0, 8, 0, 16)
        }, matchWrap())
        root.addView(Button(this).apply {
            text = "প্রেসক্রিপশনের ছবি নির্বাচন করুন"
            setOnClickListener { pickImage.launch("image/*") }
        }, matchWrap())
        preview = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.WHITE) }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 210).apply { topMargin = 12; bottomMargin = 12 })
        root.addView(TextView(this).apply {
            text = "শনাক্ত করা লেখা — প্রয়োজনমতো সম্পাদনা করুন"; textSize = 16f; setTextColor(Color.DKGRAY)
        }, matchWrap())
        editor = EditText(this).apply {
            hint = "OCR থেকে পাওয়া লেখা এখানে দেখাবে..."; gravity = Gravity.TOP or Gravity.START
            minLines = 10; textSize = 16f; setPadding(12, 12, 12, 12); setBackgroundColor(Color.WHITE)
        }
        root.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = 8; bottomMargin = 8 })
        root.addView(Button(this).apply {
            text = "ট্রান্সক্রিপশন PDF হিসেবে সংরক্ষণ"
            setOnClickListener {
                if (editor.text.isNullOrBlank()) Toast.makeText(this@MainActivity, "আগে ছবি স্ক্যান করুন বা লেখা লিখুন", Toast.LENGTH_SHORT).show()
                else createPdf.launch("prescription-transcription.pdf")
            }
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "এটি সম্পাদনাযোগ্য টেক্সট ট্রান্সক্রিপশন, মূল প্রেসক্রিপশন নয়। ওষুধ ও ডোজ চিকিৎসকের সঙ্গে যাচাই করুন।"
            textSize = 12f; setTextColor(Color.rgb(100, 70, 20)); setPadding(4, 12, 4, 0)
        }, matchWrap())
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun recognizeText(uri: Uri) {
        Toast.makeText(this, "ছবি থেকে লেখা শনাক্ত করা হচ্ছে...", Toast.LENGTH_SHORT).show()
        try {
            val image = InputImage.fromFilePath(this, uri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image).addOnSuccessListener { result ->
                editor.setText(result.text)
                Toast.makeText(this, if (result.text.isBlank()) "লেখা শনাক্ত হয়নি" else "লেখা শনাক্ত হয়েছে; ভালোভাবে মিলিয়ে নিন", Toast.LENGTH_LONG).show()
                recognizer.close()
            }.addOnFailureListener {
                Toast.makeText(this, "OCR করা যায়নি: ${it.localizedMessage}", Toast.LENGTH_LONG).show()
                recognizer.close()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "ছবি খোলা যায়নি: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun writePdf(uri: Uri) {
        val pdf = PdfDocument()
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val canvas = page.canvas
        val paint = Paint().apply { color = Color.BLACK; textSize = 12f; isAntiAlias = true }
        val heading = Paint(paint).apply { textSize = 18f; isFakeBoldText = true }
        canvas.drawText("Prescription Text Transcription", 40f, 48f, heading)
        canvas.drawText("Editable text copy — verify medicines and doses with the doctor.", 40f, 70f, paint)
        var y = 105f
        editor.text.toString().lines().forEach { line ->
            line.chunked(82).forEach { chunk ->
                if (y <= 800f) { canvas.drawText(chunk, 40f, y, paint); y += 18f }
            }
        }
        pdf.finishPage(page)
        try {
            contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }
            Toast.makeText(this, "PDF সংরক্ষণ হয়েছে", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "PDF সংরক্ষণ করা যায়নি: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        } finally { pdf.close() }
    }
}
