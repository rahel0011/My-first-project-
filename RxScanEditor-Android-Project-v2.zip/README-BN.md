# Rx Scan Editor
Android Studio project. Select a prescription image, extract Latin-script text using ML Kit OCR, edit the recognized text, and export a text transcription PDF.

Java and Kotlin compile targets are both explicitly set to JVM 17.

Note: This version uses ML Kit Latin OCR; Bengali handwriting is not reliably recognized. The exported file is a transcription draft, not an original prescription. Verify all medicine names and doses with a licensed clinician.
